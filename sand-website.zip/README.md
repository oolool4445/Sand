# SandScape Website

Simple sand-themed website project.

## Features
- Sand/desert themed UI
- Simple gallery section
- Clean layout

## How to run
Open index.html in your browser.
